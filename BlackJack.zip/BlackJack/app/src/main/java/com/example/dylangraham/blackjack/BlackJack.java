package com.example.dylangraham.blackjack;

import java.util.ArrayList;

/**
 * main class that hold all the functionality for a blackJack game
 */
public class BlackJack {

    Deck deck;

    /**
     * constructor that creates a deck
     */
    public BlackJack(){
        deck = new Deck();
    }

    /**
     * deals a new card from the deck by calling the equivalent function in Deck
     * @return card: a card from the deck
     */
    public Card dealNewCard() {
        Card card = deck.dealTheTopCard();
        return card;
    }

    /**
     * gets the value of the players hand
     * @param player: the player whose hand we are getting the count of
     * @return the int value of all the cards in the players hand
     */
    public int getCount(Player player) {
        return player.getCount();
    }

    /**
     * gets the value of the card in the game based on its number or if its a facecard. If the card
     * is an ace and using it as an 11 would force the player to go over its value is automatically
     * dropped to a 1 from the default of 11
     * @param card: the card which we will get the number of to determine its value
     * @param player: the player who holds the card we are getting the value of
     * @return the int value of the card
     */
    public int getCardValue(Card card, Player player) {
        if (card.getNum() <= 10 && card.getNum()>=2) {
            return card.getNum();
        }
        else if (card.getNum()>=11 && card.getNum()<=13){
            return 10;
        }
        else {
            if (player.getCount() <= 21) {
                return 11;
            }
            else return 1;
        }
    }

    /**
     * determines if the players hand is over 21
     * @param player: the player whose hand is being looked at
     * @return true if the player is over 21 and false if not
     */
    public boolean isBust(Player player) {
        if(getCount(player)> 21) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * resets all the game features so that a new game can be played from scratch
     * @param player: the user of the application
     * @param dealer: the computer
     */
    public void newGame(Player player, Player dealer) {
        player.resetHand();
        dealer.resetHand();
        deck.resetDeck();
        player.resetCount();
        dealer.resetCount();
    }

    /**
     * the logic behind the dealers decision to hit or stay. The dealer (as in all casinos) must
     * hit if they are below 17 and cannot hit if they are between 17 and 21
     * @param dealer: the computer
     * @return the card that the dealer is chose to draw
     */
    public Card dealerLogic (Player dealer) {
        Card cardBackup = new Card(1,5);
        if (dealer.getCount() <= 16 && dealer.getCount()<21) {
            Card card = dealNewCard();
            return card;
        }
        return cardBackup;
    }

    /**
     * checks to see if the players hand is holding 5 cards in which case they win
     * @param player: the game user
     * @return true if the hand is of size 5
     */
    public boolean handIsFive(Player player) {
        if (player.getHandSize() == 5 && player.getCount() <= 21) {
            return true;
        }
        else
            return false;
    }

    /**
     *  looks to see if the hand contains an ace. for use in determing blackjack
     * @param player: either the user of the game or the dealer
     * @return true if the hand contains an ace card
     */
    public int hasAnAce(Player player) {
        int ace = 0;
        ArrayList<Card> cards =  player.getHand();
        for (int i = 0; i< cards.size(); i++) {
            if (cards.get(i).getNum() == 1) {
                ace++;
            }
        }
        return ace;
    }

    /**
     * sees if the player has blackjack (ace and a face-card)
     * @param player: user of the game or the dealer
     * @return true if the player has blackjack
     */
    public boolean blackJackWinningHand (Player player) {
         boolean faceCard = false;
        ArrayList<Card> cards =  player.getHand();
        for (int i = 0; i< cards.size(); i++) {
            if (cards.get(i).getNum() > 10 && cards.get(i).getNum() <= 13) {
                faceCard = true;
            }
        }
            if (hasAnAce(player) >=1 && faceCard && (player.getHandSize() == 2)) {
                return true;
            }
            return false;
        }

    /**
     * logic for who the winner of the game is
     * @param dealer: computer
     * @param player: the user
     * @param winner: an optional param that would be black if not needed but could be either dealer
     *              or player if it is a specific case and they should be made sure that they win
     *              inside the controller
     * @return the winner as a String
     */
    public String declareWinner(Player dealer, Player player, String winner) {

        if (winner.equals("dealer")) {
            return "Dealer wins";
        }
        else if (winner.equals("player")) {
            return "You win!";
        }
        else if (this.blackJackWinningHand(player) && !(this.blackJackWinningHand(dealer))) {
            return "You win!";
        }
        else if (this.blackJackWinningHand(dealer) && !(this.blackJackWinningHand(player))) {
            return "Dealer wins";
        }
        else if (dealer.getCount() > 21)
        {
            return "You win!";
        }
        else if (blackJackWinningHand(player)) {
            return "You win!";
        }
        else if (player.getCount() > 21) {
            return "Dealer wins";
        }
        else if (dealer.getCount() > player.getCount()) {
            return "Dealer wins";
        }
        else if (player.getCount() > dealer.getCount()) {
            return "You win!";
        }
        else if (blackJackWinningHand(dealer)) {
            return "Dealer wins";
        }
        return "Its a draw!";
    }
}
