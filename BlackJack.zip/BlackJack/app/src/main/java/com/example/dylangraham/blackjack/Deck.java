package com.example.dylangraham.blackjack;

import java.util.ArrayList;
import java.util.Random;

/**
 * creates a deck and populates it through and ArrayList of cards
 */
public class Deck {

    private ArrayList<Card> cards;

    /**
     * constructor that creates the deck as an ArrayList and runs the function to populate it
     * with the 52 unique cards
     */
    public Deck(){
        cards = new ArrayList<Card>();
        populateTheDeck();
    }

    /**
     * repopulates the deck with all the cards for a new game
     */
    public void resetDeck() {
        populateTheDeck();
    }

    /**
     * deals the card from the ArrayList of Cards at a random index in the arrayList so that the
     * cards are always "shuffled"
     * @return a single random card
     */
    public Card dealTheTopCard() {
        Random rand = new Random();
        int length = cards.size();

        int index = rand.nextInt(length -2);
        return cards.remove(index);
    }

    /**
     * generates a deck of cards with proper suits and values
     */
    public void populateTheDeck(){
        Card newCard;
        for (int i = 1; i <= 4; i++) {          //suit
            for (int k = 1; k <= 13; k ++) {    //value/cardNum
                newCard = new Card(k, i);
                cards.add(newCard);
            }
        }
    }
}
