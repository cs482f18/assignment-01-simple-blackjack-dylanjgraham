package com.example.dylangraham.blackjack;

import java.util.ArrayList;

/**
 * includes both the user and the dealer. contains a player hand which holds the cards in the
 * players hand
 */
public class Player {
    private int count; //the count of the players hand 1-21 or bust
    private ArrayList<Card> hand;
    private boolean firstAce;
    private int aceDecrementCounter;

    /**
     *  constructor that upon creation sets first ace to true and creates the hand ArrayList
     */
    public Player () {
        hand = new ArrayList<Card>();
        this.firstAce = true;
        aceDecrementCounter = 0;
    }

    /**
     * retrieves the count (hand total) of the player
     * @return instance variable count
     */
    public int getCount() {
        return this.count;
    }

    /**
     * used when there is an ace in the hand and the player busted with the ace value being an 11
     * this drops the ace value by 10 bringing it to a 1
     */
    public int decrementCount() {
        this.aceDecrementCounter ++;
        this.count -= 10;
        return this.aceDecrementCounter;
    }

    /**
     * retrieves the hand of the player for use in searching through it to find specific cards
     * that would let us know if the player has blackjack or an ace
     * @return hand as an arrayList of Cards
     */
    public ArrayList<Card> getHand() {
        return hand;
    }

    /**
     * sets the count to the value of the cards in the hand
     * @param count: the number of the current count
     */
    public void incrementCount(int count) {
        this.count += count;
    }

    /**
     * takes in a card drawn from the deck and adds it to the array of cards in the players hand
     * @param card: the card that is drawn from the deck for this player
     */
    public void addCardToHand(Card card) {
        hand.add(card);
    }

    /**
     * retrieves the number of cards in the players hand through the size of the array
     * @return an int representing the number of cards in hand
     */
    public int getHandSize() {
       return hand.size();
    }

    /**
     * clears the hand of the player by removing the Cards from the hand arrayList
     */
    public void resetHand() {
        hand.clear();
    }

    /**
     * resets the count back to 0 for a new game
     */
    public void resetCount() {
        this.count = 0;
    }

}
