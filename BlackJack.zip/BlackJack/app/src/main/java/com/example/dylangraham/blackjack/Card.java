package com.example.dylangraham.blackjack;

/**
 * the components of a card such as the suit and number
 */
public class Card {

    private int suit;       //1=spades, 2=clubs, 3=diamonds, 4=hearts
    private int num;      //1=ace, 2=2, 3=3..., 10=10, jack=11, queen=12, king=13

    /**
     * constructor that creates a card with a number and a suit
     * @param num: the number on the card with the face cards being from 11 to 13
     * @param kind: the suit of the card i.e Spades, Clubs, Diamonds, Hearts
     */
    public Card(int num, int kind) {
        this.num = num;
        this.suit = kind;
    }

    /**
     * gives the suit of the given card
     * @return suit: the suit on the card
     */
    public int getSuit () {
        return this.suit;
    }

    /**
     * gets the number on the card with the face cards from 11-13
     * @return num: the number of the card
     */
    public int getNum () {
        return this.num;
    }

}
