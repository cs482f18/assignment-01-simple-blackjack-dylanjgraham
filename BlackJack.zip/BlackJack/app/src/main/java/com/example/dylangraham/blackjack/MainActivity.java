package com.example.dylangraham.blackjack;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Controller that communicates between the view and the model
 */
public class MainActivity extends AppCompatActivity {

    private BlackJack game;
    private Player player;
    private Player dealer;

    /**
     * pre-made function that runs on the startup of the app. declares a game a player and a
     * dealer
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        game = new BlackJack();
        player = new Player();
        dealer = new Player();

        displayPlayerCardOnScreen(game.dealNewCard());
        displayPlayerCardOnScreen(game.dealNewCard());
        displayDealerCardOnScreen(game.dealNewCard());
        displayPlayerCount();
        displayDealerCount();
    }

    /**
     * disbles the hitButton on the gui
     */
    public void disableHit() {
        Button button = (Button)findViewById(R.id.Hit);
        button.setEnabled(false);
    }

    /**
     * re-enables the hit button after a new game
     */
    public void enableHit() {
        Button button = (Button)findViewById(R.id.Hit);
        button.setEnabled(true);
    }

    /**
     * disbles the stay button
     */
    public void disableStay() {
        Button button = (Button)findViewById(R.id.Stay);
        button.setEnabled(false);
    }

    /**
     * re-enables the stay button after a new game
     */
    public void enableStay() {
        Button button = (Button)findViewById(R.id.Stay);
        button.setEnabled(true);
    }

    /**
     * onclick function for clicking the hit button. calls for a card to be dealt and displayed on
     * the screen. then calls for the count to be updated and displayed accordingly
     * @param v
     */
    public void hit (View v) {
        displayPlayerCardOnScreen(game.dealNewCard());
        displayPlayerCount();
        displayDealerCount();
        boolean dealerIsDone = false;

        if (game.isBust(player)) {
            if (game.hasAnAce(player) >=1) {
                player.decrementCount();        // puts the ace from 11 to 1 to keep from busting
                this.displayPlayerCount();
            }
            else {
                this.declareWinner(dealer, player, "dealer");
            }
        }
      if((game.handIsFive(player) && player.getCount() <= 21) || player.getCount() == 21) {
          this.disableHit();
          while (dealer.getCount() <= 16) {
              Card card =  game.dealerLogic(dealer);
              displayDealerCardOnScreen(card);
              this.disableHit();
              this.disableStay();
          }
          dealerIsDone = true;
      }
      if (dealerIsDone) {
          this.declareWinner(dealer, player, "");
      }
    }

    /**
     * onclick function for the stay button. calls on the dealer logic to begin after the player
     * chooses to stay
     * @param v
     */
    public void stay (View v) {
        int numAces = 0;
        while (dealer.getCount() <= 16) {
            Card card =  game.dealerLogic(dealer);
            displayDealerCardOnScreen(card);
            this.disableHit();
            this.disableStay();
        }
        if (game.isBust(dealer)) {
            if (game.hasAnAce(dealer)>=1) {
                numAces = dealer.decrementCount();        // puts the ace from 11 to 1 to keep from busting
                this.displayDealerCount();
            }
            if (numAces > game.hasAnAce(dealer)) {
                dealer.incrementCount(10);
                this.displayDealerCount();
            }
        }
        while (dealer.getCount() <= 16) {
            Card card =  game.dealerLogic(dealer);
            displayDealerCardOnScreen(card);
            this.disableHit();
            this.disableStay();
        }
        this.declareWinner(dealer, player, "");
    }

    /**
     * new game button click function that can be clicked at any time and deal a new hand to the
     * player and the dealer. resets the buttons, cards and counts
     * @param v
     */
    public void newGame (View v) {
        game.newGame(player, dealer);
        this.displayPlayerCount();
        this.displayDealerCount();
        ImageView cardSpot0 = findViewById(R.id.card_0);
        ImageView cardSpot1 = findViewById(R.id.card_1);
        ImageView cardSpot2 = findViewById(R.id.card_2);
        ImageView cardSpot3 = findViewById(R.id.card_3);
        ImageView cardSpot4 = findViewById(R.id.card_4);
        ImageView cardSpot5 = findViewById(R.id.card_5);
        ImageView cardSpot6 = findViewById(R.id.card_6);
        ImageView cardSpot7 = findViewById(R.id.card_7);
        ImageView cardSpot8 = findViewById(R.id.card_8);
        ImageView cardSpot9 = findViewById(R.id.card_9);

        cardSpot0.setImageResource(R.drawable.back);
        cardSpot1.setImageResource(R.drawable.back);
        cardSpot2.setImageResource(R.drawable.back);
        cardSpot3.setImageResource(R.drawable.back);
        cardSpot4.setImageResource(R.drawable.back);
        cardSpot5.setImageResource(R.drawable.back);
        cardSpot6.setImageResource(R.drawable.back);
        cardSpot7.setImageResource(R.drawable.back);
        cardSpot8.setImageResource(R.drawable.back);
        cardSpot9.setImageResource(R.drawable.back);

        displayPlayerCardOnScreen(game.dealNewCard());
        displayPlayerCardOnScreen(game.dealNewCard());
        displayDealerCardOnScreen(game.dealNewCard());
        displayPlayerCount();
        this.enableHit();
        this.enableStay();
        TextView winnerBox = findViewById(R.id.winner);
        winnerBox.setVisibility(View.INVISIBLE);
    }

    /**
     * shows the total value of the players hand inside the textview in the player section
     */
    public void displayPlayerCount() {
       int count = game.getCount(player);
       String countStr = "Count: " + count;
       TextView playerCount = findViewById(R.id.player_count);
       playerCount.setText(countStr);
    }

    /**
     * shows the total value of the dealers hand inside the textview in the dealers section
     */
    public void displayDealerCount() {
       int count = game.getCount(dealer);
       String countStr = "Count: " + count;
       TextView dealerCount = findViewById(R.id.dealer_count);
       dealerCount.setText(countStr);
    }

    /**
     * declares the winner of the game and displays it in a textview that becomes visible when the
     * game is finished
     * @param dealer: computer
     * @param player: the user of the game
     * @param PreDeclaredWinner: optional parameter
     */
    public void declareWinner (Player dealer, Player player, String PreDeclaredWinner) {
       String winner = game.declareWinner(dealer, player, PreDeclaredWinner);
       TextView winnerBox = findViewById(R.id.winner);
       winnerBox.setVisibility(View.VISIBLE);
       winnerBox.setText(winner);
    }

    /**
     * displays the cards in the player section everytime a new one is drawn by the player clicking
     * on the hit button
     * @param card
     */
    public void displayPlayerCardOnScreen(Card card) {
        //player.addCardToHand(card);
        ImageView cardSpot0 = findViewById(R.id.card_0);
        ImageView cardSpot1 = findViewById(R.id.card_1);
        ImageView cardSpot2 = findViewById(R.id.card_2);
        ImageView cardSpot3 = findViewById(R.id.card_3);
        ImageView cardSpot4 = findViewById(R.id.card_4);

        int nextCardPos = player.getHandSize();
        player.addCardToHand(card);
        player.incrementCount(game.getCardValue(card, player));
        this.displayPlayerCount();
        if (card.getSuit() == 1 && card.getNum()==1) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.ace_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.ace_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.ace_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.ace_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.ace_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==1) {
                switch (nextCardPos) {
                    case 0:
                        cardSpot0.setImageResource(R.drawable.ace_of_clubs);
                        break;
                    case 1:
                        cardSpot1.setImageResource(R.drawable.ace_of_clubs);
                        break;
                    case 2:
                        cardSpot2.setImageResource(R.drawable.ace_of_clubs);
                        break;
                    case 3:
                        cardSpot3.setImageResource(R.drawable.ace_of_clubs);
                        break;
                    case 4:
                        cardSpot4.setImageResource(R.drawable.ace_of_clubs);
                        break;
                }
        }
        else if (card.getSuit() == 3 && card.getNum()==1) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.ace_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.ace_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.ace_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.ace_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.ace_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==1) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.ace_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.ace_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.ace_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.ace_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.ace_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==2) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.two_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.two_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.two_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.two_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.two_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==2) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.two_of_clubs);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.two_of_clubs);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.two_of_clubs);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.two_of_clubs);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.two_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==2) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.two_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.two_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.two_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.two_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.two_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==2) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.two_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.two_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.two_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.two_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.two_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==3) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.three_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.three_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.three_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.three_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.three_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==3) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.three_of_clubs);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.three_of_clubs);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.three_of_clubs);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.three_of_clubs);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.three_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==3) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.three_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.three_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.three_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.three_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.three_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==3) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.three_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.three_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.three_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.three_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.three_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==4) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.four_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.four_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.four_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.four_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.four_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==4) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.four_of_clubs);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.four_of_clubs);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.four_of_clubs);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.four_of_clubs);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.four_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==4) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.four_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.four_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.four_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.four_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.four_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==4) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.four_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.four_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.four_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.four_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.four_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==5) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.five_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.five_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.five_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.five_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.five_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==5) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.five_of_clubs);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.five_of_clubs);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.five_of_clubs);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.five_of_clubs);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.five_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==5) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.five_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.five_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.five_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.five_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.five_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==5) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.five_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.five_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.five_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.five_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.five_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==6) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.six_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.six_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.six_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.six_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.six_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==6) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.six_of_clubs);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.six_of_clubs);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.six_of_clubs);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.six_of_clubs);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.six_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==6) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.six_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.six_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.six_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.six_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.six_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==6) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.six_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.six_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.six_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.six_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.six_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==7) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.seven_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.seven_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.seven_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.seven_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.seven_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==7) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.seven_of_clubs);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.seven_of_clubs);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.seven_of_clubs);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.seven_of_clubs);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.seven_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==7) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.seven_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.seven_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.seven_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.seven_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.seven_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==7) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.seven_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.seven_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.seven_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.seven_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.seven_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==8) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.eight_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.eight_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.eight_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.eight_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.eight_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==8) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.eight_of_clubs);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.eight_of_clubs);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.eight_of_clubs);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.eight_of_clubs);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.eight_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==8) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.eight_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.eight_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.eight_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.eight_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.eight_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==8) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.eight_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.eight_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.eight_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.eight_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.eight_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==9) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.nine_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.nine_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.nine_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.nine_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.nine_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==9) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.nine_of_clubs);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.nine_of_clubs);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.nine_of_clubs);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.nine_of_clubs);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.nine_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==9) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.nine_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.nine_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.nine_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.nine_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.nine_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==9) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.nine_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.nine_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.nine_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.nine_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.nine_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==10) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.ten_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.ten_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.ten_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.ten_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.ten_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==10) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.ten_of_clubs);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.ten_of_clubs);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.ten_of_clubs);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.ten_of_clubs);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.ten_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==10) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.ten_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.ten_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.ten_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.ten_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.ten_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==10) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.ten_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.ten_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.ten_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.ten_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.ten_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==11) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.jack_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.jack_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.jack_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.jack_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.jack_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==11) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.jack_of_clubs);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.jack_of_clubs);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.jack_of_clubs);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.jack_of_clubs);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.jack_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==11) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.jack_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.jack_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.jack_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.jack_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.jack_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==11) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.jack_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.jack_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.jack_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.jack_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.jack_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==12) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.queen_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.queen_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.queen_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.queen_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.queen_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==12) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.queen_of_clubs);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.queen_of_clubs);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.queen_of_clubs);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.queen_of_clubs);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.queen_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==12) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.queen_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.queen_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.queen_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.queen_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.queen_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==12) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.queen_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.queen_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.queen_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.queen_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.queen_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==13) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.king_of_spades);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.king_of_spades);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.king_of_spades);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.king_of_spades);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.king_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==13) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.king_of_clubs);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.king_of_clubs);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.king_of_clubs);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.king_of_clubs);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.king_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==13) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.king_of_diamonds);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.king_of_diamonds);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.king_of_diamonds);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.king_of_diamonds);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.king_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==13) {
            switch (nextCardPos) {
                case 0:
                    cardSpot0.setImageResource(R.drawable.king_of_hearts);
                    break;
                case 1:
                    cardSpot1.setImageResource(R.drawable.king_of_hearts);
                    break;
                case 2:
                    cardSpot2.setImageResource(R.drawable.king_of_hearts);
                    break;
                case 3:
                    cardSpot3.setImageResource(R.drawable.king_of_hearts);
                    break;
                case 4:
                    cardSpot4.setImageResource(R.drawable.king_of_hearts);
                    break;
            }
        }
    }

    /**
     * displays the dealer cards on the screen in the dealer section everytime the dealer decides
     * they want another card
     * @param card
     */
    public void displayDealerCardOnScreen(Card card) {
        //player.addCardToHand(card);
        ImageView cardSpot5 = findViewById(R.id.card_5);
        ImageView cardSpot6 = findViewById(R.id.card_6);
        ImageView cardSpot7 = findViewById(R.id.card_7);
        ImageView cardSpot8 = findViewById(R.id.card_8);
        ImageView cardSpot9 = findViewById(R.id.card_9);

        int nextCardPos = dealer.getHandSize();
        dealer.addCardToHand(card);
        dealer.incrementCount(game.getCardValue(card, player));
        if (card.getSuit() == 1 && card.getNum()==1) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.ace_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.ace_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.ace_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.ace_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.ace_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==1) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.ace_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.ace_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.ace_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.ace_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.ace_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==1) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.ace_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.ace_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.ace_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.ace_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.ace_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==1) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.ace_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.ace_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.ace_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.ace_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.ace_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==2) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.two_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.two_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.two_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.two_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.two_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==2) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.two_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.two_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.two_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.two_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.two_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==2) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.two_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.two_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.two_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.two_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.two_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==2) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.two_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.two_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.two_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.two_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.two_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==3) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.three_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.three_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.three_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.three_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.three_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==3) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.three_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.three_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.three_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.three_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.three_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==3) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.three_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.three_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.three_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.three_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.three_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==3) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.three_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.three_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.three_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.three_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.three_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==4) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.four_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.four_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.four_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.four_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.four_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==4) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.four_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.four_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.four_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.four_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.four_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==4) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.four_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.four_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.four_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.four_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.four_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==4) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.four_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.four_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.four_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.four_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.four_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==5) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.five_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.five_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.five_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.five_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.five_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==5) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.five_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.five_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.five_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.five_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.five_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==5) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.five_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.five_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.five_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.five_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.five_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==5) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.five_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.five_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.five_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.five_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.five_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==6) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.six_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.six_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.six_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.six_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.six_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==6) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.six_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.six_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.six_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.six_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.six_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==6) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.six_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.six_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.six_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.six_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.six_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==6) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.six_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.six_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.six_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.six_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.six_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==7) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.seven_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.seven_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.seven_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.seven_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.seven_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==7) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.seven_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.seven_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.seven_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.seven_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.seven_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==7) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.seven_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.seven_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.seven_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.seven_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.seven_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==7) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.seven_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.seven_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.seven_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.seven_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.seven_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==8) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.eight_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.eight_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.eight_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.eight_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.eight_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==8) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.eight_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.eight_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.eight_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.eight_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.eight_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==8) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.eight_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.eight_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.eight_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.eight_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.eight_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==8) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.eight_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.eight_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.eight_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.eight_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.eight_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==9) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.nine_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.nine_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.nine_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.nine_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.nine_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==9) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.nine_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.nine_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.nine_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.nine_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.nine_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==9) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.nine_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.nine_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.nine_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.nine_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.nine_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==9) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.nine_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.nine_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.nine_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.nine_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.nine_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==10) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.ten_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.ten_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.ten_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.ten_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.ten_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==10) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.ten_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.ten_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.ten_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.ten_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.ten_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==10) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.ten_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.ten_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.ten_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.ten_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.ten_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==10) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.ten_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.ten_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.ten_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.ten_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.ten_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==11) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.jack_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.jack_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.jack_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.jack_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.jack_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==11) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.jack_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.jack_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.jack_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.jack_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.jack_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==11) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.jack_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.jack_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.jack_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.jack_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.jack_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==11) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.jack_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.jack_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.jack_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.jack_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.jack_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==12) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.queen_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.queen_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.queen_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.queen_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.queen_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==12) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.queen_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.queen_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.queen_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.queen_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.queen_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==12) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.queen_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.queen_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.queen_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.queen_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.queen_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==12) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.queen_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.queen_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.queen_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.queen_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.queen_of_hearts);
                    break;
            }
        }
        else if (card.getSuit() == 1 && card.getNum()==13) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.king_of_spades);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.king_of_spades);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.king_of_spades);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.king_of_spades);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.king_of_spades);
                    break;
            }
        }
        else if (card.getSuit() == 2 && card.getNum()==13) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.king_of_clubs);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.king_of_clubs);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.king_of_clubs);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.king_of_clubs);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.king_of_clubs);
                    break;
            }
        }
        else if (card.getSuit() == 3 && card.getNum()==13) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.king_of_diamonds);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.king_of_diamonds);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.king_of_diamonds);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.king_of_diamonds);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.king_of_diamonds);
                    break;
            }
        }
        else if (card.getSuit() == 4 && card.getNum()==13) {
            switch (nextCardPos) {
                case 0:
                    cardSpot5.setImageResource(R.drawable.king_of_hearts);
                    break;
                case 1:
                    cardSpot6.setImageResource(R.drawable.king_of_hearts);
                    break;
                case 2:
                    cardSpot7.setImageResource(R.drawable.king_of_hearts);
                    break;
                case 3:
                    cardSpot8.setImageResource(R.drawable.king_of_hearts);
                    break;
                case 4:
                    cardSpot9.setImageResource(R.drawable.king_of_hearts);
                    break;
            }
        }
        displayDealerCount();
    }

}
